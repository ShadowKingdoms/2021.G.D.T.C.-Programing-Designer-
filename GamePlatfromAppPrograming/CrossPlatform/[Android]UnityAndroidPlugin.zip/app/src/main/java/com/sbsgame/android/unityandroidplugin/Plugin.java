package com.sbsgame.android.unityandroidplugin;

import android.app.Activity;
import android.content.DialogInterface;
import android.widget.Toast;
import android.app.AlertDialog;

public class Plugin {
    static Activity m_Activity = null;
    //유니티로부터 액티비티를 받음.
    void SetAcivity(Activity activity)
    {
        m_Activity = activity;
    }
    //유니티에 1000값을 리턴함
    int GetInt()
    {
        return 1000;
    }

    void ToastMsg(Activity activity, String msg, int time)
    {
        Toast cToast = Toast.makeText(activity.getApplicationContext(),msg,time);
        cToast.show();
    }

    void AlertDialogExit(Activity activity, String title, String massage)
    {
        // 다이얼로그 바디
        AlertDialog.Builder alertdialog = new AlertDialog.Builder(activity);
        // 다이얼로그 메세지
        alertdialog.setTitle(title);
        alertdialog.setMessage(massage);

        // 확인버튼
        alertdialog.setPositiveButton("Yes", new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog, int which) {
                System.exit(0);
            }
        });

        // 취소버튼
        alertdialog.setNegativeButton("No", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        alertdialog.create().show();
    }
}

