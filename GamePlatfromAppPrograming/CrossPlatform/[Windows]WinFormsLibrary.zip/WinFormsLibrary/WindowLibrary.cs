﻿using System;
using System.Windows.Forms;

namespace WinFormsLibrary
{
    public class WindowLibrary
    {
        public int GetInt()
        {
            return 20210830;
        }
        public void ShowMessageBox()
        {
            DialogResult result = MessageBox.Show("test1", "test2", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                MessageBox.Show("yes", "yes");
            }
            else
            {
                MessageBox.Show("no", "no");
            }
        }
    }
}
