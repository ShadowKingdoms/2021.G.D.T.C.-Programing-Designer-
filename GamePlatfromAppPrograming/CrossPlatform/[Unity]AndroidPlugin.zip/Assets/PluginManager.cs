﻿using UnityEngine;
using UnityWinFormsLibrary;

public class PluginManager : MonoBehaviour 
{
#if UNITY_STANDALONE_WIN || UNITY_EDITOR_WIN

#elif UNITY_ANDROID
    private AndroidJavaObject m_AndroidJavaObject = null;
    private AndroidJavaObject m_ActivityInstance = null;
#elif UNITY_IOS
#endif
    // Use this for initialization
    void Start () {
#if UNITY_STANDALONE_WIN || UNITY_EDITOR_WIN

#elif UNITY_ANDROID //안드로이드에서만 빌드가능하도록설정
        //안드로이드로 부터 액티비티를 생성하고,액티비티를 가져옴.
        using (AndroidJavaClass unityPlayerClass = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
        {
            m_ActivityInstance = unityPlayerClass.GetStatic<AndroidJavaObject>("currentActivity");
            Debug.LogWarning("PluginManager.AndroidJavaObject::currentActivity");
        }
        //플러그인에 만든 클래스를 인스턴스화 (패키지경로+클래스명: 대소문자 틀리면안됨)
        m_AndroidJavaObject = new AndroidJavaObject("com.sbsgame.android.unityandroidplugin.Plugin");
        Debug.LogWarning("PluginManager.AndroidJavaObject:" + m_AndroidJavaObject);
#endif
    }

    private void OnGUI() //출력용 레거시GUI
    {
        int nNavitiveData = GetInt();

        GUI.Box(new Rect(0, 0, 200, 20), "GetInt:" + nNavitiveData);
 
        if (GUI.Button(new Rect(0, 20, 200, 20), "Toast Msg"))
        {
            ToastMsg("Test",20);
        }
        if (GUI.Button(new Rect(0, 40, 200, 100), "MessageBoxExit"))
        {
            MessageBox("종료","정말로 종료 하시겠습니까?");
        }
    }

    int GetInt() //다른 플랫폼에서도 정상 작동하도록 바로 값리턴하지않고 중간값을 생성
    {
        int nResult = -1;
#if UNITY_STANDALONE_WIN || UNITY_EDITOR_WIN
        nResult = UnityWinformsPlugin.GetInt();
#elif UNITY_ANDROID
        if (m_AndroidJavaObject != null)
            nResult = m_AndroidJavaObject.Call<int>("GetInt");
        else
            Debug.LogError("AndroidJavaObject is null!!!");
#endif
        Debug.LogWarning("PluginManager.GetInt() End");
        return nResult; 
    }

    //안드로이드에서 토스트메세지를 실행함.
    void ToastMsg(string msg, int time)
    {
#if UNITY_STANDALONE_WIN || UNITY_EDITOR_WIN
        UnityWinformsPlugin.ShowMessageBoxExit("test", "test");
#elif UNITY_ANDROID
        if (m_AndroidJavaObject != null)
            m_AndroidJavaObject.Call("ToastMsg", m_ActivityInstance,msg,time);
        else
            Debug.LogError("AndroidJavaObject is null!!!");
#endif
    }

    void MessageBox(string title, string msg)
    {
#if UNITY_STANDALONE_WIN || UNITY_EDITOR_WIN
        UnityWinformsPlugin.ShowMessageBoxExit(msg, title);
#elif UNITY_ANDROID
        if (m_AndroidJavaObject != null)
            m_AndroidJavaObject.Call("AlertDialogExit", m_ActivityInstance,title,msg);
        else
            Debug.LogError("AndroidJavaObject is null!!!");
#endif
    }
}