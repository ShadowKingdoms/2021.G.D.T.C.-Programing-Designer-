﻿using UnityEngine;

using UnityEngine;
//유니티 풀스크린모드 만들기(현재버전에는 사용할필요가 없음)
public class DisableSystemUI //: MonoBehaviour
{
    public const int NOTHIDE = 0;
    public const int HIDEING = 1;
    public const int HIDE = 2;
    public const int HIDED = 3;

#if UNITY_ANDROID
    static AndroidJavaObject m_ActivityInstance;
    static AndroidJavaObject m_WindowInstance;
    static AndroidJavaObject m_ViewInstance;

    static int m_nSoftBarStatus = NOTHIDE;
    //안드로이드에 플래그번호를 미리 설정함.
    const int SYSTEM_UI_FLAG_HIDE_NAVIGATION = 2;
    const int SYSTEM_UI_FLAG_LAYOUT_STABLE = 256;
    const int SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION = 512;
    const int SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN = 1024;
    const int SYSTEM_UI_FLAG_IMMERSIVE = 2048;
    const int SYSTEM_UI_FLAG_IMMERSIVE_STICKY = 4096;
    const int SYSTEM_UI_FLAG_FULLSCREEN = 4;

    static public AndroidJavaObject GetActivityInstance()
    {
        return m_ActivityInstance;
    }

    public static int CheckHide()
    {
        return m_nSoftBarStatus;
    }

    public static void CheckedHIde()
    {
        m_nSoftBarStatus = HIDED;
    }

    public delegate void RunPtr();

    public static void Run()
    {
        if (m_ViewInstance != null)
        {
            //안드로이드 뷰에 셋팅을 미리설정된 옵선에 맞게 유니티에서 설정함.
            m_ViewInstance.Call("setSystemUiVisibility",
                              SYSTEM_UI_FLAG_LAYOUT_STABLE
                              | SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                              | SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                              | SYSTEM_UI_FLAG_HIDE_NAVIGATION
                              | SYSTEM_UI_FLAG_FULLSCREEN
                              | SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            //바의 상태체크값을 변경함.
            m_nSoftBarStatus = HIDE;
        }

    }
#endif
    public static void DisableNavUI()
    {
        if (Application.platform != RuntimePlatform.Android)
            return;
#if UNITY_ANDROID
        //유니티 플레이어로 부터, 액티비티,윈도우,뷰를 얻어온다.
        using (AndroidJavaClass unityPlayerClass = new AndroidJavaClass("com.unity3d.player.UnityPlayer"))
        {
            m_ActivityInstance = unityPlayerClass.GetStatic<AndroidJavaObject>("currentActivity");
            m_WindowInstance = m_ActivityInstance.Call<AndroidJavaObject>("getWindow");
            m_ViewInstance = m_WindowInstance.Call<AndroidJavaObject>("getDecorView");

            //자바에 스래드를 이용하여 Run함수를 호출시킨다.
            AndroidJavaRunnable RunThis;
            RunThis = new AndroidJavaRunnable(new RunPtr(Run));
            m_ActivityInstance.Call("runOnUiThread", RunThis);

            m_nSoftBarStatus = HIDEING;
        }
#endif
    }

}